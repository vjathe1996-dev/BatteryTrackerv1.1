# Changelog

## v1.1
Fixes
- The app no longer polls in the background: live values only refresh while the app is on screen (saves battery).
- Reboots are detected with Android's own boot counter, so a clock change can't end a session by mistake.
- Charge, low-battery and overheat alerts remember that they fired, so they don't repeat after the app restarts.
- Sessions now end at the moment the charger is plugged or unplugged, with the final level and charge counter.
- Battery percentage is rounded (matches Android) instead of cut down.
- App lock: if the phone's screen lock is removed, the lock is turned off with a message instead of quietly opening.
- Background failures are logged instead of swallowed; cancelled work is handled correctly.
Data
- CSV export now stores exact times, charge counters and screen percentages, and quotes text properly.
  Import reads both the new and the old (v1.0) files, skips bad rows, and keeps capacity estimates.
Performance
- Home loads only recent sessions, Insights only the last 120 days, and the database is written less often.
- Insights keeps up after midnight and no longer recalculates every chart on each refresh.
Polish
- Dark-mode launch no longer flashes white; own notification icon; notification text and app name moved to strings.xml.
- Screenshot blocking is now off by default (turn it on in Settings > Security).
- Newer AndroidX and Compose libraries; new unit tests for CSV, rounding and current readings.

## v1.0 (pre-release build 2)
Fixes: gaps after reboot no longer counted as charge/drain; short unplug blips merge back into one charge;
docks/other chargers labelled "Other"; app lock grace period; keyboard no longer covers fields;
Home uses Android's own time-to-full / time-left when available.
Accuracy: database writes throttled; level samples recorded (per-session graph, charge taper model);
time held at full also counts adaptive-charging holds; background pulse every 15 min and on app open.
Interface: real icons, scroll position kept per tab, accessibility description on battery ring,
first-run guide, warnings when notifications are off or background use is restricted.
Data: CSV import, auto-delete old history option, database indexes. Unit tests for core maths.
Not yet done: translations (strings still in code), premium/ads, final app ID, release signing key.

## Battery use by app (Details tab)
Optional Usage access; per-app screen time and estimated battery share (matched to battery readings); tap an app for details.
