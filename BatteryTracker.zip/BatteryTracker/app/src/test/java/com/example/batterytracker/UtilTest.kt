package com.example.batterytracker

import org.junit.Assert.assertEquals
import org.junit.Test

class UtilTest {
    @Test
    fun roundsBatteryPercent() {
        assertEquals(100, roundPct(996, 1000))
        assertEquals(50, roundPct(50, 100))
        assertEquals(0, roundPct(4, 1000))
        assertEquals(0, roundPct(10, 0))
    }

    @Test
    fun normalisesCurrent() {
        assertEquals(0, normMa(Int.MIN_VALUE))
        assertEquals(850, normMa(-850))
        assertEquals(1800, normMa(1_800_000))
    }
}
