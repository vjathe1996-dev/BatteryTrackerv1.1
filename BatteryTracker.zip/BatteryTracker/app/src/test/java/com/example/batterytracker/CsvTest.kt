package com.example.batterytracker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CsvTest {
    private fun session(start: Long, charging: Boolean = true, source: String = "AC") = Session(
        charging = charging, startTime = start, endTime = start + 3_600_000L,
        startPct = 20, endPct = 80, source = source, maxTempC = 31.5f, open = false,
        fullMs = 600_000L, screenOnMs = 1_200_000L, screenOffMs = 2_400_000L,
        screenOnPct = 5, screenOffPct = 3, startCounterUah = 1_000_000L, endCounterUah = 3_000_000L
    )

    @Test
    fun parsesQuotedFields() {
        assertEquals(listOf("a", "b,c", "d\"e"), parseCsvLine("a,\"b,c\",\"d\"\"e\""))
    }

    @Test
    fun exportThenImportKeepsEverything() {
        val original = listOf(session(1_700_000_000_000L), session(1_700_100_000_000L, charging = false, source = "Battery"))
        val back = parseSessions(toCsv(original).lines())
        assertEquals(2, back.size)
        assertEquals(original[0].startTime, back[0].startTime)
        assertEquals(original[0].endCounterUah, back[0].endCounterUah)
        assertEquals(original[0].screenOnPct, back[0].screenOnPct)
        assertTrue(!back[1].charging)
    }

    @Test
    fun oldFormatStillImports() {
        val header = "type,start,end,duration_min,start_pct,end_pct,change_pct,source,max_temp_c,time_at_100_min,screen_on_min,screen_off_min"
        val row = "charge,2025-01-01 10:00:00,2025-01-01 11:00:00,60,20,80,60,AC,31.5,10,20,40"
        val back = parseSessions(listOf(header, row))
        assertEquals(1, back.size)
        assertEquals(3_600_000L, back[0].endTime - back[0].startTime)
    }

    @Test
    fun badRowsAreSkipped() {
        val header = "type,start,end,duration_min,start_pct,end_pct,change_pct,source,max_temp_c,time_at_100_min,screen_on_min,screen_off_min"
        val bad = "charge,2025-01-01 10:00:00,2025-01-01 11:00:00,60,20,180,60,AC,31.5,10,20,40"
        assertEquals(0, parseSessions(listOf(header, bad, "garbage")).size)
    }
}
