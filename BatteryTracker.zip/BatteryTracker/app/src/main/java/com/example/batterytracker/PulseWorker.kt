package com.example.batterytracker

import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException

class PulseWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            val pm = applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
            Tracker.pulse(applicationContext, pm.isInteractive)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Battery pulse failed", e)
        }
        if (!BatteryService.running) {
            // Android 12+ can refuse to start a foreground service from the background.
            // The pulse above already recorded the reading, so this is only a best effort.
            try {
                ContextCompat.startForegroundService(
                    applicationContext, Intent(applicationContext, BatteryService::class.java)
                )
            } catch (e: Exception) {
                Log.w(TAG, "Could not restart the tracking service from the background", e)
            }
        }
        return Result.success()
    }

    private companion object {
        const val TAG = "PulseWorker"
    }
}
