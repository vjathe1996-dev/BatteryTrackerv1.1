package com.example.batterytracker

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sessions", indices = [Index("startTime"), Index("open")])
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val charging: Boolean,
    val startTime: Long,
    val endTime: Long,
    val startPct: Int,
    val endPct: Int,
    val source: String,
    val maxTempC: Float,
    val open: Boolean = true,
    val fullMs: Long = 0,
    val screenOnMs: Long = 0,
    val screenOffMs: Long = 0,
    val screenOnPct: Int = 0,
    val screenOffPct: Int = 0,
    val startCounterUah: Long = 0,
    val endCounterUah: Long = 0
)

@Entity(tableName = "samples", indices = [Index("sessionId")])
data class Sample(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val time: Long,
    val pct: Int,
    val tempC: Float,
    val currentMa: Int
)

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY startTime DESC")
    fun all(): Flow<List<Session>>

    @Query("SELECT * FROM sessions ORDER BY startTime DESC LIMIT :n")
    fun recent(n: Int): Flow<List<Session>>

    @Query("SELECT * FROM sessions WHERE startTime >= :from ORDER BY startTime DESC")
    fun since(from: Long): Flow<List<Session>>

    @Query("SELECT COUNT(*) FROM sessions WHERE open = 0")
    fun closedCount(): Flow<Int>

    @Query("SELECT * FROM sessions ORDER BY startTime DESC")
    suspend fun snapshot(): List<Session>

    @Query("SELECT * FROM sessions WHERE open = 1 LIMIT 1")
    suspend fun openSession(): Session?

    @Query("SELECT * FROM sessions WHERE open = 0 AND endTime <= :t ORDER BY endTime DESC LIMIT 1")
    suspend fun lastClosedBefore(t: Long): Session?

    @Query("DELETE FROM sessions")
    suspend fun clearAll()

    @Query("DELETE FROM sessions WHERE open = 0 AND endTime < :cutoff")
    suspend fun deleteOlderThan(cutoff: Long)

    @Insert suspend fun insert(s: Session): Long
    @Update suspend fun update(s: Session)
    @Delete suspend fun delete(s: Session)

    @Insert suspend fun insertSample(s: Sample)

    @Query("SELECT * FROM samples WHERE sessionId = :id ORDER BY time")
    suspend fun samplesFor(id: Long): List<Sample>

    @Query("SELECT samples.* FROM samples INNER JOIN sessions ON sessions.id = samples.sessionId WHERE sessions.charging = 1 AND sessions.open = 0 ORDER BY samples.time DESC LIMIT 1500")
    fun chargeSamples(): Flow<List<Sample>>

    @Query("SELECT samples.* FROM samples INNER JOIN sessions ON sessions.id = samples.sessionId WHERE sessions.charging = 0 AND samples.time >= :from ORDER BY samples.sessionId, samples.time")
    suspend fun dischargeSamplesSince(from: Long): List<Sample>

    @Query("DELETE FROM samples WHERE sessionId = :id")
    suspend fun deleteSamples(id: Long)

    @Query("DELETE FROM samples")
    suspend fun clearSamples()

    @Query("DELETE FROM samples WHERE sessionId IN (SELECT id FROM sessions WHERE open = 0 AND endTime < :cutoff)")
    suspend fun deleteSamplesOlderThan(cutoff: Long)
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE sessions ADD COLUMN fullMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOnMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOffMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOnPct INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOffPct INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN startCounterUah INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN endCounterUah INTEGER NOT NULL DEFAULT 0")
    }
}

private val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sessions_startTime` ON `sessions` (`startTime`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sessions_open` ON `sessions` (`open`)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `samples` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `time` INTEGER NOT NULL, `pct` INTEGER NOT NULL, `tempC` REAL NOT NULL, `currentMa` INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_samples_sessionId` ON `samples` (`sessionId`)")
    }
}

@Database(entities = [Session::class, Sample::class], version = 3, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): SessionDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(c: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "battery.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build().also { instance = it }
        }
    }
}
