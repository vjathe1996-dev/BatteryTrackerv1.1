package com.example.batterytracker

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

private fun pctText(p: Double): String = if (p < 0.5) "<1%" else "~${p.roundToInt()}%"

@Composable
fun AppUsageSection() {
    val ctx = LocalContext.current
    val access by pollWhileStarted(false, 2000L) { hasUsageAccess(ctx) }
    var range by rememberSaveable { mutableStateOf(0) }
    var expanded by remember { mutableStateOf<String?>(null) }
    val result by produceState<AppUsageResult?>(null, access, range) {
        value = null
        if (access) {
            val now = System.currentTimeMillis()
            val from = if (range == 0) startOfToday() else now - 7 * 86_400_000L
            value = withContext(Dispatchers.IO) {
                try {
                    loadAppUsage(ctx, from, now)
                } catch (e: Exception) {
                    null
                }
            }
        }
    }

    Section("Battery use by app") {
        if (!access) {
            Text("See which apps were on screen the most and an estimate of how much battery each used.")
            Text(
                "This needs Usage access, which you turn on in Android settings. The information stays on your phone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = { openSafely(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Allow usage access") }
        } else {
            FilterRow(listOf("Today", "Last 7 days"), range) {
                range = it
                expanded = null
            }
            val r = result
            if (r == null) {
                Text("Calculating…")
            } else if (r.apps.isEmpty()) {
                Text("No app usage found for this period yet. Use your phone unplugged for a while and check back.")
            } else {
                val maxPct = maxOf(r.apps.maxOf { it.estPct }, r.backgroundPct).coerceAtLeast(0.1)
                val totalFg = r.apps.sumOf { it.fgMs }
                Text("Battery used in this period: ${r.totalDrainPct}%", fontWeight = FontWeight.Bold)
                r.apps.take(12).forEach { a ->
                    AppRow(a, maxPct, totalFg, expanded == a.pkg) {
                        expanded = if (expanded == a.pkg) null else a.pkg
                    }
                }
                if (r.backgroundPct >= 0.5) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Screen off and background", fontWeight = FontWeight.Bold)
                            Text(pctText(r.backgroundPct), fontWeight = FontWeight.Bold, color = Orange)
                        }
                        LinearProgressIndicator(
                            progress = { (r.backgroundPct / maxPct).coerceIn(0.0, 1.0).toFloat() },
                            modifier = Modifier.fillMaxWidth(), color = Orange
                        )
                    }
                }
            }
            Text(
                "Estimates based on how long each app was on screen and when your battery dropped. They are not exact. Android's own battery screen shows exact figures.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AppRow(app: AppUse, maxPct: Double, totalFg: Long, expanded: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val icon = remember(app.pkg) {
        try {
            ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    val fmt = remember { SimpleDateFormat("EEE, d MMM · h:mm a", Locale.getDefault()) }
    Column(
        Modifier.fillMaxWidth().clickable { onClick() }.animateContentSize(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (icon != null) Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(36.dp))
            else Spacer(Modifier.size(36.dp))
            Column(Modifier.weight(1f)) {
                Text(app.label, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${formatDuration(app.fgMs)} on screen",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(pctText(app.estPct), fontWeight = FontWeight.Bold, color = Orange)
        }
        LinearProgressIndicator(
            progress = { (app.estPct / maxPct).coerceIn(0.0, 1.0).toFloat() },
            modifier = Modifier.fillMaxWidth(), color = Orange
        )
        if (expanded) {
            Detail("Screen time", formatDuration(app.fgMs))
            Detail("Share of screen time", if (totalFg > 0) "%.0f%%".format(app.fgMs * 100.0 / totalFg) else "n/a")
            Detail("Estimated battery used", "%.1f%%".format(app.estPct))
            Detail("Opened", "${app.launches} times")
            Detail("Last used", fmt.format(Date(app.lastUsed)))
            OutlinedButton(
                onClick = {
                    openSafely(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Open app info") }
        }
    }
}
