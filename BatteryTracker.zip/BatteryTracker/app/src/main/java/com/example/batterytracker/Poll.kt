package com.example.batterytracker

import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay

private tailrec fun Context.findLifecycleOwner(): LifecycleOwner? = when (this) {
    is LifecycleOwner -> this
    is ContextWrapper -> baseContext.findLifecycleOwner()
    else -> null
}

/**
 * Re-reads a value every [periodMs] but ONLY while the app is on screen.
 * When the app goes to the background the loop stops, so the tracker itself does not waste battery.
 */
@Composable
fun <T> pollWhileStarted(initial: T, periodMs: Long, key: Any? = null, block: suspend () -> T): State<T> {
    val ctx = LocalContext.current
    val owner = remember(ctx) { ctx.findLifecycleOwner() }
    return produceState(initial, owner, key) {
        if (owner == null) {
            while (true) {
                value = block()
                delay(periodMs)
            }
        } else {
            owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    value = block()
                    delay(periodMs)
                }
            }
        }
    }
}
