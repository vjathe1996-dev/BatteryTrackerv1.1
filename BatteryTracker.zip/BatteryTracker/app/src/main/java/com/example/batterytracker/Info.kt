package com.example.batterytracker

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

typealias InfoSection = Pair<String, List<Pair<String, String>>>

fun readInfo(ctx: Context, useF: Boolean): List<InfoSection> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return emptyList()
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val na = "n/a"

    val level = roundPct(
        i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0),
        i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    )
    val status = when (i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
        else -> "Unknown"
    }
    val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
    val plugText = when (plug) {
        0 -> "Not plugged in"
        BatteryManager.BATTERY_PLUGGED_AC -> "AC charger"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        else -> "Other"
    }
    val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unknown"
    }
    val tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
    val voltage = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
    val cycles = if (Build.VERSION.SDK_INT >= 34) i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) else -1

    val ma = normMa(safe { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } ?: Int.MIN_VALUE)
    val maAvg = normMa(safe { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE) } ?: Int.MIN_VALUE)
    val counter = safe { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) } ?: Long.MIN_VALUE
    val energy = safe { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_ENERGY_COUNTER) } ?: Long.MIN_VALUE

    val watts = if (ma > 0 && voltage > 0) "%.1f W".format(voltage / 1000.0 * ma / 1000.0) else na
    val toFull: Long = if (Build.VERSION.SDK_INT >= 28 && plug != 0) {
        safe { bm.computeChargeTimeRemaining() } ?: -1L
    } else -1L
    val timeLeft: String = if (Build.VERSION.SDK_INT >= 33) {
        safe { pm.batteryDischargePrediction?.toMillis() }?.let { formatDuration(it) } ?: na
    } else na
    val soh: Int? = if (Build.VERSION.SDK_INT >= 34) {
        safe { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATE_OF_HEALTH) }
    } else null
    val thermal: String = if (Build.VERSION.SDK_INT >= 29) {
        when (safe { pm.currentThermalStatus }) {
            0 -> "Normal"
            1 -> "Light"
            2 -> "Moderate"
            3 -> "Severe"
            4 -> "Critical"
            5 -> "Emergency"
            6 -> "Shutdown"
            else -> na
        }
    } else na
    val unrestricted = safe { pm.isIgnoringBatteryOptimizations(ctx.packageName) } ?: false

    return listOf(
        "Charging now" to listOf(
            "Level" to "$level%",
            "Status" to status,
            "Charger" to plugText,
            "Power" to watts,
            "Current now" to if (ma > 0) "$ma mA" else na,
            "Current average" to if (maAvg > 0) "$maAvg mA" else na,
            "Voltage" to "%.2f V".format(voltage / 1000f),
            "Time to full (Android)" to if (toFull > 0) formatDuration(toFull) else na,
            "Time left (Android)" to timeLeft
        ),
        "Battery condition" to listOf(
            "Health" to health,
            "State of health" to if (soh != null && soh in 1..100) "$soh%" else na,
            "Cycle count" to if (cycles >= 0) "$cycles" else na,
            "Technology" to (i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.ifBlank { null } ?: na),
            "Battery present" to if (i.getBooleanExtra(BatteryManager.EXTRA_PRESENT, true)) "Yes" else "No",
            "Temperature" to fmtTemp(tempC, useF)
        ),
        "Counters" to listOf(
            "Charge left" to if (counter > 0) "%.0f mAh".format(counter / 1000.0) else na,
            "Energy left" to if (energy > 0) "%.0f mWh".format(energy / 1_000_000.0) else na
        ),
        "Power state" to listOf(
            "Battery saver" to if (pm.isPowerSaveMode) "On" else "Off",
            "Screen" to if (pm.isInteractive) "On" else "Off",
            "Doze (idle mode)" to if (pm.isDeviceIdleMode) "Active" else "Inactive",
            "Thermal status" to thermal,
            "Background use" to if (unrestricted) "Unrestricted" else "Optimized (may be limited)"
        ),
        "Phone" to listOf(
            "Manufacturer" to Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            "Model" to Build.MODEL,
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Security patch" to (Build.VERSION.SECURITY_PATCH.ifBlank { na })
        )
    )
}
