package com.example.batterytracker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.BatteryManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max
import kotlin.math.roundToInt

object Tracker {
    data class Reading(val pct: Int, val charging: Boolean)

    private const val BLIP_MS = 120_000L
    private const val MERGE_MS = 5 * 60_000L
    private const val WRITE_MS = 60_000L
    private const val SAMPLE_MS = 5 * 60_000L
    private const val LONG_GAP_MS = 30 * 60_000L

    private val mutex = Mutex()
    @Volatile var screenOn = true
    private var lastSampleTime = 0L
    private var lastSamplePct = -1
    private var lastPrune = 0L

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("tracker", ctx.getString(R.string.channel_tracker), NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel("alerts", ctx.getString(R.string.channel_alerts), NotificationManager.IMPORTANCE_HIGH)
        )
    }

    suspend fun pulse(ctx: Context, screen: Boolean?) {
        val app = ctx.applicationContext
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        handle(app, i, screen)
    }

    suspend fun handle(ctx: Context, i: Intent, newScreen: Boolean?): Reading? = mutex.withLock {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return@withLock null
        val pct = roundPct(level, scale)
        val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val charging = plug != 0
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
        val held = charging && (status == BatteryManager.BATTERY_STATUS_FULL || status == BatteryManager.BATTERY_STATUS_NOT_CHARGING)
        val source = when (plug) {
            0 -> "Battery"
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "Other"
        }
        val app = ctx.applicationContext
        val dao = AppDb.get(app).dao()
        val bm = app.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val sp = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val rawCounter = safe { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) } ?: 0L
        val counter = if (rawCounter > 0 && rawCounter != Long.MIN_VALUE) rawCounter else 0L
        val now = System.currentTimeMillis()

        var cur = dao.openSession()

        // Android counts reboots itself, so a clock change can never look like a restart.
        val bootCount = safe { Settings.Global.getInt(app.contentResolver, Settings.Global.BOOT_COUNT) } ?: -1
        val lastCount = sp.getInt("bootCount", -1)
        val rebooted = bootCount >= 0 && lastCount >= 0 && bootCount != lastCount
        if (bootCount >= 0 && bootCount != lastCount) sp.edit().putInt("bootCount", bootCount).apply()
        val beforeReboot = cur
        if (beforeReboot != null && rebooted) {
            finish(dao, beforeReboot)
            cur = null
        }

        var forceWrite = false
        val old = cur
        if (old != null && old.charging != charging) {
            if (old.endTime - old.startTime < BLIP_MS) {
                dao.deleteSamples(old.id)
                dao.delete(old)
                val prev = dao.lastClosedBefore(old.startTime)
                if (prev != null && prev.charging == charging && old.startTime - prev.endTime < MERGE_MS) {
                    cur = prev.copy(open = true)
                    forceWrite = true
                } else {
                    cur = null
                }
            } else {
                // Close at the real moment the charger was plugged or unplugged (unless there was a long gap).
                val closed = if (now - old.endTime <= LONG_GAP_MS) {
                    old.copy(
                        open = false, endTime = now, endPct = pct,
                        maxTempC = max(old.maxTempC, temp),
                        endCounterUah = if (counter > 0) counter else old.endCounterUah
                    )
                } else old.copy(open = false)
                dao.update(closed)
                cur = null
                prune(sp, dao, now)
            }
        }

        val c = cur
        if (c != null) {
            val el = now - c.endTime
            val dp = pct - c.endPct
            var u = c.copy(
                endTime = now, endPct = pct,
                maxTempC = max(c.maxTempC, temp),
                endCounterUah = if (counter > 0) counter else c.endCounterUah
            )
            if (el > 0 && el <= LONG_GAP_MS) {
                u = if (screenOn) u.copy(screenOnMs = c.screenOnMs + el, screenOnPct = c.screenOnPct + dp)
                else u.copy(screenOffMs = c.screenOffMs + el, screenOffPct = c.screenOffPct + dp)
            }
            if (el > 0 && charging && (held || c.endPct >= 100)) {
                u = u.copy(fullMs = c.fullMs + el)
            }
            val changed = forceWrite || pct != c.endPct || el >= WRITE_MS || newScreen != null || temp > c.maxTempC
            if (changed) dao.update(u)
            sample(dao, bm, c.id, now, pct, temp, false)
        } else {
            val id = dao.insert(
                Session(
                    charging = charging, startTime = now, endTime = now,
                    startPct = pct, endPct = pct, source = source, maxTempC = temp,
                    startCounterUah = counter, endCounterUah = counter
                )
            )
            sample(dao, bm, id, now, pct, temp, true)
        }

        if (newScreen != null) screenOn = newScreen
        checkAlerts(app, sp, pct, charging, temp)
        Reading(pct, charging)
    }

    private suspend fun finish(dao: SessionDao, s: Session) {
        if (s.endTime - s.startTime < BLIP_MS) {
            dao.deleteSamples(s.id)
            dao.delete(s)
        } else {
            dao.update(s.copy(open = false))
        }
    }

    private suspend fun sample(dao: SessionDao, bm: BatteryManager, id: Long, now: Long, pct: Int, temp: Float, force: Boolean) {
        if (!force && pct == lastSamplePct && now - lastSampleTime < SAMPLE_MS) return
        val ma = normMa(safe { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } ?: Int.MIN_VALUE)
        dao.insertSample(Sample(sessionId = id, time = now, pct = pct, tempC = temp, currentMa = ma))
        lastSamplePct = pct
        lastSampleTime = now
    }

    private suspend fun prune(sp: SharedPreferences, dao: SessionDao, now: Long) {
        val days = sp.getInt("keepDays", 0)
        if (days <= 0 || now - lastPrune < 3_600_000L) return
        lastPrune = now
        val cutoff = now - days * 86_400_000L
        dao.deleteSamplesOlderThan(cutoff)
        dao.deleteOlderThan(cutoff)
    }

    private fun alert(ctx: Context, id: Int, title: String, text: String) {
        ensureChannels(ctx)
        val pi = PendingIntent.getActivity(ctx, id, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        ctx.getSystemService(NotificationManager::class.java).notify(
            id,
            NotificationCompat.Builder(ctx, "alerts")
                .setSmallIcon(R.drawable.ic_stat_battery)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
        )
    }

    private fun flag(sp: SharedPreferences, key: String) = sp.getBoolean(key, false)

    private fun setFlag(sp: SharedPreferences, key: String, value: Boolean) {
        sp.edit().putBoolean(key, value).apply()
    }

    // Alert state is saved, so restarting the app or phone does not repeat the same alert.
    private fun checkAlerts(ctx: Context, sp: SharedPreferences, pct: Int, charging: Boolean, temp: Float) {
        if (sp.getBoolean("limitOn", true)) {
            val lim = sp.getInt("limitPct", 100)
            if (charging && pct >= lim) {
                if (!flag(sp, "limitAlerted")) {
                    setFlag(sp, "limitAlerted", true)
                    alert(ctx, 2, ctx.getString(R.string.alert_limit_title), ctx.getString(R.string.alert_limit_text, pct))
                }
            } else if (!charging && flag(sp, "limitAlerted")) setFlag(sp, "limitAlerted", false)
        }
        if (sp.getBoolean("lowOn", true)) {
            val low = sp.getInt("lowPct", 15)
            if (!charging && pct <= low) {
                if (!flag(sp, "lowAlerted")) {
                    setFlag(sp, "lowAlerted", true)
                    alert(ctx, 3, ctx.getString(R.string.alert_low_title), ctx.getString(R.string.alert_low_text, pct))
                }
            } else if ((charging || pct > low + 3) && flag(sp, "lowAlerted")) setFlag(sp, "lowAlerted", false)
        }
        if (sp.getBoolean("heatOn", true)) {
            val heat = sp.getInt("heatC", 40)
            if (temp >= heat) {
                if (!flag(sp, "heatAlerted")) {
                    setFlag(sp, "heatAlerted", true)
                    alert(ctx, 4, ctx.getString(R.string.alert_heat_title), ctx.getString(R.string.alert_heat_text, temp.roundToInt()))
                }
            } else if (temp < heat - 3 && flag(sp, "heatAlerted")) setFlag(sp, "heatAlerted", false)
        }
    }
}
