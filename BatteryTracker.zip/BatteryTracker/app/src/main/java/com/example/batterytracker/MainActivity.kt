package com.example.batterytracker

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

private val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or
    BiometricManager.Authenticators.DEVICE_CREDENTIAL

class MainActivity : FragmentActivity() {
    private lateinit var settings: AppSettings
    private var unlocked by mutableStateOf(false)
    private var authenticating = false
    private var stoppedAt = 0L

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        settings = AppSettings(getSharedPreferences("settings", MODE_PRIVATE))
        applySecure(settings.secureOn)
        startTracking()
        scheduleWatchdog()

        setContent {
            val dark = when (settings.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            AppTheme(dark) {
                Surface(Modifier.fillMaxSize()) {
                    if (!settings.lockOn || unlocked) {
                        if (!settings.onboarded) {
                            OnboardingScreen(
                                onNotifications = { askNotifications() },
                                onBattery = {
                                    openSafely(this@MainActivity, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                },
                                onUsage = {
                                    openSafely(this@MainActivity, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                                },
                                onDone = {
                                    settings.onboarded = true
                                    settings.save()
                                }
                            )
                        } else {
                            AppScreen(settings, { setLock(it) }, { setSecure(it) })
                        }
                    } else {
                        LockScreen { authenticate() }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (settings.lockOn) {
            val away = SystemClock.elapsedRealtime() - stoppedAt
            if (unlocked && !authenticating && away > settings.lockGraceSec * 1000L) unlocked = false
            if (!unlocked) authenticate()
        }
        lifecycleScope.launch(Dispatchers.IO) { Tracker.pulse(applicationContext, true) }
    }

    override fun onStop() {
        super.onStop()
        if (!authenticating) stoppedAt = SystemClock.elapsedRealtime()
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else openNotificationSettings(this)
    }

    private fun authenticate() {
        if (authenticating) return
        val status = BiometricManager.from(this).canAuthenticate(AUTH)
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            if (status == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ||
                status == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
            ) {
                // The phone has no screen lock any more, so the app lock cannot work. Turn it off and say so.
                settings.lockOn = false
                settings.save()
                unlocked = true
                Toast.makeText(this, getString(R.string.lock_turned_off), Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, getString(R.string.lock_unavailable), Toast.LENGTH_SHORT).show()
            }
            return
        }
        authenticating = true
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticating = false
                    unlocked = true
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticating = false
                }
            }
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Battery Tracker")
                .setAllowedAuthenticators(AUTH)
                .build()
        )
    }

    private fun setLock(on: Boolean): Boolean {
        if (on && BiometricManager.from(this).canAuthenticate(AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Set a screen lock (PIN, pattern, or fingerprint) in phone settings first.", Toast.LENGTH_LONG).show()
            return false
        }
        settings.lockOn = on
        settings.save()
        unlocked = true
        return true
    }

    private fun setSecure(on: Boolean) {
        settings.secureOn = on
        settings.save()
        applySecure(on)
    }

    private fun applySecure(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun startTracking() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, BatteryService::class.java))
        } catch (e: Exception) {
            Log.w("MainActivity", "Could not start the tracking service", e)
        }
    }

    private fun scheduleWatchdog() {
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "pulse", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<PulseWorker>(15, TimeUnit.MINUTES).build()
        )
    }
}

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(primary = Green) else lightColorScheme(primary = Green)
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun AppScreen(settings: AppSettings, onLock: (Boolean) -> Boolean, onSecure: (Boolean) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val homeState = rememberLazyListState()
    val historyState = rememberLazyListState()
    val insightsScroll = rememberScrollState()
    val detailsScroll = rememberScrollState()
    val settingsScroll = rememberScrollState()
    val tabs = listOf(
        R.drawable.ic_nav_home to "Home",
        R.drawable.ic_nav_history to "History",
        R.drawable.ic_nav_chart to "Insights",
        R.drawable.ic_nav_info to "Details",
        R.drawable.ic_nav_settings to "Settings"
    )
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(painterResource(t.first), contentDescription = null) },
                        label = { Text(t.second) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    0 -> HomeScreen(settings, homeState)
                    1 -> HistoryScreen(settings, historyState)
                    2 -> InsightsScreen(settings, insightsScroll)
                    3 -> DetailsScreen(settings, detailsScroll)
                    else -> SettingsScreen(settings, onLock, onSecure, settingsScroll)
                }
            }
        }
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", style = MaterialTheme.typography.displayMedium)
        Spacer(Modifier.height(12.dp))
        Text("Battery Tracker is locked", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onUnlock) { Text("Unlock") }
    }
}
