package com.example.batterytracker

import android.content.Context
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Locale

/** Splits one CSV line, understanding "quoted, fields" and "" escapes. */
fun parseCsvLine(line: String): List<String> {
    val out = ArrayList<String>()
    val cur = StringBuilder()
    var quoted = false
    var i = 0
    while (i < line.length) {
        val c = line[i]
        when {
            quoted && c == '"' && i + 1 < line.length && line[i + 1] == '"' -> {
                cur.append('"')
                i++
            }
            c == '"' -> quoted = !quoted
            c == ',' && !quoted -> {
                out.add(cur.toString())
                cur.setLength(0)
            }
            else -> cur.append(c)
        }
        i++
    }
    out.add(cur.toString())
    return out
}

/** Turns CSV lines (first line is the header) into sessions. Bad rows are skipped. */
fun parseSessions(lines: List<String>): List<Session> {
    val f = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    val out = ArrayList<Session>()
    for (line in lines.drop(1)) {
        if (line.isBlank()) continue
        val p = parseCsvLine(line.trimEnd('\r'))
        if (p.size < 12) continue
        try {
            val newFormat = p.size >= 18
            // Version 1.1 files carry exact times in milliseconds. Older files only have text times.
            val start = if (newFormat) p[12].toLong() else (f.parse(p[1])?.time ?: continue)
            val end = if (newFormat) p[13].toLong() else (f.parse(p[2])?.time ?: continue)
            val startPct = p[4].toInt()
            val endPct = p[5].toInt()
            if (end < start || startPct !in 0..100 || endPct !in 0..100) continue
            out.add(
                Session(
                    charging = p[0] == "charge",
                    startTime = start, endTime = end,
                    startPct = startPct, endPct = endPct,
                    source = p[7].ifBlank { "Other" },
                    maxTempC = p[8].toFloat(),
                    open = false,
                    fullMs = p[9].toLong() * 60_000,
                    screenOnMs = p[10].toLong() * 60_000,
                    screenOffMs = p[11].toLong() * 60_000,
                    screenOnPct = if (newFormat) p[16].toInt() else 0,
                    screenOffPct = if (newFormat) p[17].toInt() else 0,
                    startCounterUah = if (newFormat) p[14].toLong() else 0L,
                    endCounterUah = if (newFormat) p[15].toLong() else 0L
                )
            )
        } catch (e: Exception) {
            continue
        }
    }
    return out
}

suspend fun importCsv(ctx: Context, uri: Uri, dao: SessionDao): Int {
    val lines = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readLines() } ?: return 0
    val existing = dao.snapshot().map { it.startTime }.toHashSet()
    var n = 0
    for (s in parseSessions(lines)) {
        if (s.startTime in existing) continue
        dao.insert(s)
        existing.add(s.startTime)
        n++
    }
    return n
}
