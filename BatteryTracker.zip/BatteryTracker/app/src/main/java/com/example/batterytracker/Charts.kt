package com.example.batterytracker

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun BarChart(labels: List<String>, values: List<Float>, color: Color, unit: String) {
    var sel by remember(values) { mutableIntStateOf(-1) }
    val maxV = (values.maxOrNull() ?: 0f).coerceAtLeast(1f)
    Column(Modifier.fillMaxWidth()) {
        Text(
            if (sel in values.indices) "${labels[sel]}: ${"%.0f".format(values[sel])}$unit" else "Tap a bar for details",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Canvas(
            Modifier.fillMaxWidth().height(140.dp).pointerInput(values) {
                detectTapGestures { off ->
                    if (values.isNotEmpty()) {
                        val slotW = size.width.toFloat() / values.size
                        sel = (off.x / slotW).toInt().coerceIn(0, values.size - 1)
                    }
                }
            }
        ) {
            val n = values.size.coerceAtLeast(1)
            val slot = size.width / n
            val bw = slot * 0.6f
            values.forEachIndexed { i, v ->
                val h = (size.height * (v / maxV)).coerceAtLeast(2f)
                drawRoundRect(
                    color = if (i == sel) color else color.copy(alpha = 0.55f),
                    topLeft = Offset(i * slot + (slot - bw) / 2, size.height - h),
                    size = Size(bw, h),
                    cornerRadius = CornerRadius(4.dp.toPx())
                )
            }
        }
        if (labels.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(labels.first(), style = MaterialTheme.typography.labelSmall)
                Text(labels.last(), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun LineChart(values: List<Float>, color: Color) {
    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
        if (values.size < 2) return@Canvas
        val mn = values.min()
        val span = (values.max() - mn).coerceAtLeast(1f)
        val pts = values.mapIndexed { i, v ->
            Offset(
                i * size.width / (values.size - 1),
                size.height * 0.9f - (v - mn) / span * size.height * 0.8f
            )
        }
        val path = Path().apply {
            moveTo(pts[0].x, pts[0].y)
            pts.drop(1).forEach { lineTo(it.x, it.y) }
        }
        drawPath(path, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
        pts.forEach { drawCircle(color, 4.dp.toPx(), it) }
    }
}

@Composable
fun HBars(items: List<Pair<String, Double>>, color: Color, unit: String) {
    val maxV = (items.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(0.1)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { (name, v) ->
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name)
                    Text("%.1f %s".format(v, unit), fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(progress = { (v / maxV).toFloat() }, modifier = Modifier.fillMaxWidth(), color = color)
            }
        }
    }
}

@Composable
fun TimeChart(times: List<Long>, values: List<Float>, color: Color) {
    Canvas(Modifier.fillMaxWidth().height(100.dp)) {
        if (values.size < 2 || times.size != values.size) return@Canvas
        val t0 = times.first()
        val span = (times.last() - t0).coerceAtLeast(1L).toFloat()
        val mn = values.min()
        val vs = (values.max() - mn).coerceAtLeast(1f)
        val pts = values.indices.map { i ->
            Offset(
                (times[i] - t0) / span * size.width,
                size.height * 0.92f - (values[i] - mn) / vs * size.height * 0.84f
            )
        }
        val path = Path().apply {
            moveTo(pts[0].x, pts[0].y)
            pts.drop(1).forEach { lineTo(it.x, it.y) }
        }
        drawPath(path, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
    }
}
