package com.example.batterytracker

import kotlin.math.abs

/** Runs [block] and returns null if the phone throws (many battery APIs are not on every device). */
internal fun <T> safe(block: () -> T): T? = try {
    block()
} catch (e: Exception) {
    null
}

/** Current readings come in µA or mA depending on the phone. Returns a positive mA value, or 0 if unknown. */
internal fun normMa(raw: Int): Int {
    if (raw == Int.MIN_VALUE) return 0
    val a = abs(raw)
    return if (a >= 10_000) a / 1000 else a
}

/** Battery percentage rounded to the nearest whole number (matches what Android shows). */
fun roundPct(level: Int, scale: Int): Int =
    if (scale <= 0) 0 else Math.round(level * 100f / scale).coerceIn(0, 100)
